<?php $__env->startSection('title', 'Login: Larapets 🐶'); ?>

<?php $__env->startSection('content'); ?>
    <section class="bg-[#0006] text-white rounded-lg w-96 gap-2 p-8 flex flex-col items-center justify-center">
        <h1 class="flex gap-2 justify-center items-center text-4xl">
            <svg xmlns="http://www.w3.org/2000/svg" class="size-12" fill="currentColor" viewBox="0 0 256 256"><path d="M230.92,212c-15.23-26.33-38.7-45.21-66.09-54.16a72,72,0,1,0-73.66,0C63.78,166.78,40.31,185.66,25.08,212a8,8,0,1,0,13.85,8c18.84-32.56,52.14-52,89.07-52s70.23,19.44,89.07,52a8,8,0,1,0,13.85-8ZM72,96a56,56,0,1,1,56,56A56.06,56.06,0,0,1,72,96Z"></path></svg>
            Login
        </h1>
        <form method="">
            <div class="card w-full max-w-sm">
            <form method="POST" action="<?php echo e(route('login')); ?>" class="card-body">
                <?php echo csrf_field(); ?>
                <label class="label">Email</label>
                <input type="text" class="input" placeholder="Email" />
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-error text-sm mt-1"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <label class="label">Password</label>
                <input type="password" class="input" placeholder="Password" />
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-error text-sm mt-1"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <button class="btn btn-outline hover:bg-[#fff6] hover:text-white mt-4">Login</button>

                <p class="text-sm text-center mt-4">
                    Don’t have an account?
                    <a href="<?php echo e(route('register')); ?>" class="link link-default">
                        Sign up
                    </a>
                </p>
            </form>
        </div>
        </form>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Federico\Desktop\adso3063934\20-laravel\resources\views/auth/login.blade.php ENDPATH**/ ?>